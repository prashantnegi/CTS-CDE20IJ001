package com.cognizant.truyum.dao;

public class CartEmptyException extends Exception {

	/**
	 * A Cart Empty exception should be thrown if the userCart cart is accessed when
	 * there are no items present inside it.
	 */
	private static final long serialVersionUID = 1L;

	public CartEmptyException() {
		super();
	}
}
