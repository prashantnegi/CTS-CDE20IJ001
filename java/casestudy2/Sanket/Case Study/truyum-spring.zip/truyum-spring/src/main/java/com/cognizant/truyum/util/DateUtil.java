package com.cognizant.truyum.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public final class DateUtil {
	
	private DateUtil(){
		
	}
	
	public static Date convertToDate(String date){
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy"); 
		Date d = null;
		try {
			d =df.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return d;
	}
}
