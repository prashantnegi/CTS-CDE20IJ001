package com.cognizant.truyum.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cognizant.truyum.AnnotationConfig;
import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.util.DateUtil;

class MenuItemServiceTest {

	MenuItemService service;
	private AnnotationConfigApplicationContext context;
	List<MenuItem> menuItemListAdmin;
	List<MenuItem> menuItemListCustomer;

	@BeforeEach
	public void initializeService() {
		context = new AnnotationConfigApplicationContext(AnnotationConfig.class);
		service = (MenuItemService) context.getBean("menuItemService");
		//context.scan("");
		menuItemListAdmin = service.getMenuItemListAdmin();
		menuItemListCustomer = service.getMenuItemListCustomer();
	}

	@Test
	void testGetMenuItemListAdminSize() {
		assertEquals(5, menuItemListAdmin.size());
	}

	@ParameterizedTest
	@ValueSource(strings = { "Sandwich", "Burger", "Pizza", "French Fries", "Chocolate Brownie" })
	void testGetMenuItemListAdminContainsItems(String itemName) {
		assertTrue(isItemPresent(menuItemListAdmin, itemName));
	}

	@Test
	void testGetMenuItemListCustomerSize() {
		assertEquals(3, menuItemListCustomer.size());
	}

	@ParameterizedTest
	@ValueSource(strings = { "Sandwich", "Burger", "Pizza" })
	void testGetMenuItemListCustomerContainsItems(String itemName) {
		assertTrue(isItemPresent(menuItemListCustomer, itemName));
	}

	@ParameterizedTest
	@ValueSource(strings = { "French Fries", "Chocolate Brownie" })
	void testGetMenuItemListCustomerNotContainsItems(String itemName) {
		assertFalse(isItemPresent(menuItemListCustomer, itemName));
	}

	@Test
	void testGetMenuItem() {
		assertEquals(menuItemListAdmin.get(0), service.getMenuItem(1));
	}

	@Test
	void testModifyMenuItem() {
		MenuItem brownie = new MenuItem(5, "Chocolate Brownie", 70.00f, true, DateUtil.convertToDate("02/11/2022"),
				"Dessert", true);
		service.editMenuItem(brownie);
		assertEquals(brownie, service.getMenuItem(5));
	}

	@AfterEach
	public void stopService() {
		context.close();
	}

	private boolean isItemPresent(List<MenuItem> menuItemList, String itemName) {
		return menuItemList.stream().map((item) -> item.getName()).collect(Collectors.toList()).contains(itemName);
	}
}
