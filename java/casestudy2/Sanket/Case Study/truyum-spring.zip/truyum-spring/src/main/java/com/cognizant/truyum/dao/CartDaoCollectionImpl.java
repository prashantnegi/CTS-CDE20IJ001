package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cognizant.truyum.model.Cart;
import com.cognizant.truyum.model.MenuItem;

@Component
public class CartDaoCollectionImpl implements CartDao {
	@Autowired
	private Map<Long, Cart> userCarts;
	@Autowired
	private MenuItemDao menuItemDao;

	public  Map<Long, Cart> getUserCarts() {
		return userCarts;
	}

	public  void setUserCarts(Map<Long, Cart> userCarts) {
		this.userCarts = userCarts;
	}

	

	@Override
	public void addCartItem(long userId, long menuItemId) {
		MenuItem menuItem = menuItemDao.getMenuItem(menuItemId);
		List<MenuItem> menuItemList;
		if (userCarts.containsKey(userId)) {
			menuItemList = userCarts.get(userId).getMenuItemList();
			menuItemList.add(menuItem);
		} else {
			menuItemList = new ArrayList<>();
			Cart cart = new Cart(menuItemList, 0);
			menuItemList.add(menuItem);
			userCarts.put(userId, cart);
		}
	}

	@Override
	public List<MenuItem> getAllCartItems(long userId) throws CartEmptyException {

		Cart cart = Optional.ofNullable(userCarts.get(userId)).orElseThrow(CartEmptyException::new);
		List<MenuItem> menuItemList = cart.getMenuItemList();

		double total = menuItemList.stream().mapToDouble(MenuItem::getPrice).sum();
		cart.setTotal(total);
		return Optional.ofNullable(menuItemList).filter(menuItem -> !menuItem.isEmpty())
				.orElseThrow(CartEmptyException::new);
	}

	@Override
	public void removeCartItem(long userId, long menuItemId) {
		List<MenuItem> menuItemList = userCarts.get(userId).getMenuItemList();
		MenuItem item = menuItemList.stream().filter(menuItem -> menuItem.getId() == menuItemId)
				.collect(Collectors.toList()).get(0);
		menuItemList.remove(item);
	}

}
