package com.cognizant.truyum.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cognizant.truyum.AnnotationConfig;
import com.cognizant.truyum.dao.CartEmptyException;
import com.cognizant.truyum.model.MenuItem;

class CartServiceTest {

	CartService cartService;
	MenuItemService menuItemService;
	private AnnotationConfigApplicationContext context;
	List<MenuItem> menuItemListAdmin;
	List<MenuItem> menuItemListCustomer;
	private List<MenuItem> menuItemList;

	@BeforeEach
	public void initializeService() {
		context = new AnnotationConfigApplicationContext(AnnotationConfig.class);
		cartService = context.getBean(CartService.class);
		menuItemService = context.getBean(MenuItemService.class);
		menuItemList = menuItemService.getMenuItemListCustomer();
	}

	@Test
	void testAddCartItem() {
		cartService.addCartItem(1, 1);
		try {
			assertEquals(menuItemList.get(0), cartService.getAllCartItems(1).get(0));
		} catch (CartEmptyException e) {
			fail("Check the logic for addCartItem and getAllCartItems");
		}
	}

	@Test
	void testGetAllCartItemsWithoutAddingAnuItem() throws CartEmptyException {
		assertThrows(CartEmptyException.class, () -> cartService.getAllCartItems(1));
	}

	@Test
	void testRemoveCartItemWithoutMakingTheCartEmpty() {
		cartService.addCartItem(1, 1);
		cartService.addCartItem(1, 2);
		cartService.removeCartItem(1, 1);
		try {
			assertEquals(menuItemList.get(1), cartService.getAllCartItems(1).get(0));
		} catch (CartEmptyException e) {
			e.printStackTrace();
		}
	}

	@Test
	void testRemoveCartItemMakingTheCartEmpty() throws CartEmptyException {
		cartService.addCartItem(1, 1);
		cartService.removeCartItem(1, 1);
		assertThrows(CartEmptyException.class, () -> cartService.getAllCartItems(1));
	}

	@AfterEach
	public void stopService() {
		context.close();
	}
}
