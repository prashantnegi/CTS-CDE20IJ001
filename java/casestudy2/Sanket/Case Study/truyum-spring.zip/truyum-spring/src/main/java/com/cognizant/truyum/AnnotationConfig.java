package com.cognizant.truyum;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

import com.cognizant.truyum.model.Cart;


@Configuration
@ImportResource("classpath:spring-config.xml")
@ComponentScan("com.cognizant.truyum")
/*
 * The Spring config file
 * Scan the Base package
 * Include the xml config file
 */
public class AnnotationConfig {
	
	@Bean
    public Map<Long, Cart> userCarts () {
        return new HashMap<>();
    }
}
