package com.cognizant.truyum.dao;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import com.cognizant.truyum.model.MenuItem;
public class MenuItemDaoCollectionImpl implements MenuItemDao {

	private List<MenuItem> menuItemList;

	public List<MenuItem> getMenuItemList() {
		return this.menuItemList;
	}
	@Autowired
	public MenuItemDaoCollectionImpl(List<MenuItem> menuItemList) {
		super();
		this.menuItemList = menuItemList;
	}

	@Override
	public List<MenuItem> getMenuItemListAdmin() {

		return menuItemList;
	}

	@Override
	public List<MenuItem> getMenuItemListCustomer() {
		return menuItemList.stream()
				.filter(menuItem -> menuItem.getDateOfLaunch().before(new Date()))
				.filter(MenuItem::isActive).collect(Collectors.toList());
	}

	@Override
	public void modifyMenuItem(MenuItem menuItem) {
		menuItemList.stream().filter(m -> m.equals(menuItem))
				.forEach(m -> menuItemList.set(menuItemList.indexOf(m), menuItem));
	}

	@Override
	public MenuItem getMenuItem(long menuItemId) {
		return menuItemList.stream().filter(m -> m.getId() == menuItemId).collect(Collectors.toList())
				.get(0);
	}

}
